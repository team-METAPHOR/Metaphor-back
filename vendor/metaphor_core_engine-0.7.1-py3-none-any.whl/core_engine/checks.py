"""Deterministic UI predicates; model output is data, never JavaScript."""

import asyncio
from dataclasses import dataclass
import time
from urllib.parse import urlsplit

from .policy import PolicyError, SAFE_METHODS, STATE_CHANGING_METHODS, canonical_url


STATE_ATTRIBUTES = {
    "aria-pressed": ("true", "false", "mixed"),
    "aria-checked": ("true", "false", "mixed"),
    "aria-expanded": ("true", "false"),
    "aria-selected": ("true", "false"),
    "aria-busy": ("true", "false"),
    "aria-disabled": ("true", "false"),
}


@dataclass(frozen=True)
class Check:
    kind: str
    selector: str
    value: str
    other_selector: str = ""

    def __post_init__(self):
        if self.kind not in {"text", "visible", "enabled", "count", "overlap", "clipped", "response_status", "url_path", "attribute"}:
            raise ValueError("unsupported UI check")
        if not isinstance(self.selector, str) or not (0 if self.kind == "url_path" else 1) <= len(self.selector) <= 256:
            raise ValueError("invalid check selector")
        if not isinstance(self.value, str) or len(self.value) > 2000:
            raise ValueError("invalid check value")
        if self.kind in {"visible", "enabled", "overlap", "clipped"} and self.value not in {"true", "false"}:
            raise ValueError("boolean checks use true/false")
        if self.kind == "count" and (not self.value.isascii() or not self.value.isdigit() or not 0 <= int(self.value) <= 1000):
            raise ValueError("count must be 0..1000")
        if not isinstance(self.other_selector, str) or len(self.other_selector) > 256:
            raise ValueError("invalid secondary selector")
        if self.kind == "url_path":
            if self.selector or self.other_selector or not self.value.startswith("/") or "?" in self.value or canonical_url("https://scope.invalid" + self.value) != "https://scope.invalid" + self.value:
                raise ValueError("URL check requires only an exact canonical path value")
        elif self.kind == "attribute":
            if self.other_selector not in STATE_ATTRIBUTES or self.value not in STATE_ATTRIBUTES[self.other_selector]:
                raise ValueError("attribute check requires an allowlisted ARIA state and value")
        elif self.kind == "response_status":
            if self.other_selector not in SAFE_METHODS | STATE_CHANGING_METHODS or not self.value.isascii() or not self.value.isdigit() or not 100 <= int(self.value) <= 599:
                raise ValueError("response check needs an allowed method and HTTP status")
            if not self.selector.startswith("/") or "?" in self.selector or canonical_url("https://scope.invalid" + self.selector) != "https://scope.invalid" + self.selector:
                raise ValueError("response check requires an exact canonical path")
        elif (self.kind == "overlap") != bool(self.other_selector):
            raise ValueError("only overlap requires a secondary selector")


async def observe_check(page, check, network=None) -> bool:
    """Missing/ambiguous elements are blocked except explicit visibility/count checks."""
    if not isinstance(check, Check):
        # Legacy TextCheck keeps its visible-element semantics.
        check = Check("text", check.selector, check.text)
    if check.kind == "url_path":
        return urlsplit(page.url).path == check.value
    if check.kind == "response_status":
        matching = [item for item in (network or []) if item["method"] == check.other_selector
                    and urlsplit(item["url"]).path == check.selector]
        if not matching or matching[-1].get("status") is None or matching[-1].get("blocker"):
            raise PolicyError("RESPONSE_NOT_OBSERVED")
        return matching[-1]["status"] == int(check.value)
    locator = page.locator("css=" + check.selector)
    count = await locator.count()
    if check.kind == "count":
        return count == int(check.value)
    if check.kind == "visible":
        if count > 1:
            raise PolicyError("AMBIGUOUS_CHECK_TARGET")
        visible = count == 1 and await locator.is_visible()
        return visible == (check.value == "true")
    if count != 1 or not await locator.is_visible():
        raise PolicyError("CHECK_TARGET_UNAVAILABLE")
    if check.kind == "text":
        return (await locator.inner_text()).strip() == check.value.strip()
    if check.kind == "attribute":
        actual = await locator.get_attribute(check.other_selector)
        if actual not in STATE_ATTRIBUTES[check.other_selector]:
            raise PolicyError("CHECK_ATTRIBUTE_UNAVAILABLE")
        return actual == check.value
    if check.kind == "enabled":
        actual = await locator.is_enabled()
    elif check.kind == "overlap":
        other = page.locator("css=" + check.other_selector)
        if await other.count() != 1 or not await other.is_visible():
            raise PolicyError("CHECK_TARGET_UNAVAILABLE")
        a, b = await locator.bounding_box(), await other.bounding_box()
        if not a or not b:
            raise PolicyError("CHECK_TARGET_UNAVAILABLE")
        actual = (min(a["x"] + a["width"], b["x"] + b["width"]) - max(a["x"], b["x"]) > 1
                  and min(a["y"] + a["height"], b["y"] + b["height"]) - max(a["y"], b["y"]) > 1)
    else:
        # Fixed, read-only engine code, never generated by the model.
        actual = await locator.evaluate("""el => {
            const r = el.getBoundingClientRect();
            return r.left < -1 || r.top < -1 || r.right > innerWidth + 1 || r.bottom > innerHeight + 1
                || el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1;
        }""")
    return actual == (check.value == "true")


async def wait_for_check(page, check, timeout_ms, guard, network=None):
    deadline = time.monotonic() + timeout_ms / 1000
    while True:
        guard()
        try:
            if await observe_check(page, check, network):
                return
        except PolicyError as exc:
            if exc.code not in {"CHECK_TARGET_UNAVAILABLE", "CHECK_ATTRIBUTE_UNAVAILABLE", "RESPONSE_NOT_OBSERVED"}:
                raise
        if time.monotonic() >= deadline:
            raise PolicyError("STEP_OR_READINESS_FAILED")
        await asyncio.sleep(0.05)
